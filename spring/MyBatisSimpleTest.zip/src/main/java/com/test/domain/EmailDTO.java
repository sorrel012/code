package com.test.domain;

import lombok.Data;

@Data
public class EmailDTO {

	private String seq;
	private String email;
	private String pseq;
	
}
